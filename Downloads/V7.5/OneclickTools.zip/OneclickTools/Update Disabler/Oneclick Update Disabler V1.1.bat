:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

:: Start Log.
echo [%DATE% %TIME%] Update Disabler V1.1: Successfully started. >> "C:\Oneclick Logs\Oneclick Log.txt"

:: Creating Update Policy Reg Backup.
reg export "HKLM\SOFTWARE\Microsoft\WindowsUpdate" "C:\Oneclick Tools\Update Disabler\Reg Backup\PolicyBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Update Disabler Reg Policy Backup: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] Update Disabler Reg Policy Backup: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Windows Update Service Backup.
reg export "HKLM\SYSTEM\CurrentControlSet\Services\wuauserv" "C:\Oneclick Tools\Update Disabler\Reg Backup\WindowsUpdateServiceBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Update Disabler Service Backup #1: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] Update Disabler Service Backup #1: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Update Orchestrator Service Backup.
reg export "HKLM\SYSTEM\CurrentControlSet\Services\UsoSvc" "C:\Oneclick Tools\Update Disabler\Reg Backup\UpdateOrchestratorServiceBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Update Disabler Service Backup #2: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] Update Disabler Service Backup #2: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Windows Update Medic Service Backup.
reg export "HKLM\SYSTEM\CurrentControlSet\Services\WaaSMedicSvc" "C:\Oneclick Tools\Update Disabler\Reg Backup\WindowsUpdateMedicServiceBackup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Update Disabler Service Backup #3: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] Update Disabler Service Backup #3: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Update Apps Backup #1.
xcopy "C:\Windows\UUS" "C:\Oneclick Tools\Update Disabler\Apps Backup\USS" /E /I /H /Y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] Update Disabler Apps Backup #1: Failed to copy all files. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] Update Disabler Apps Backup #1: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Update Apps Backup #2.
setlocal enabledelayedexpansion
set "BackupDir=C:\Oneclick Tools\Update Disabler\Apps Backup\System32"
set "File1=C:\Windows\System32\DoSvc.dll"
set "File2=C:\Windows\System32\en-US\DoSvc.dll.mui"
set "File3=C:\Windows\System32\MoNotificationUxStub.exe"
set "File4=C:\Windows\System32\MusUpdateHandlers.dll"
set "File5=C:\Windows\System32\en-US\MusUpdateHandlers.dll.mui"
set "File6=C:\Windows\System32\MusUpdateHandlers1.dll"
set "File7=C:\Windows\System32\en-US\MusUpdateHandlers1.dll.mui"
set "File8=C:\Windows\System32\Sihclient.exe"
set "File9=C:\Windows\System32\en-US\sihclient.exe.mui"
set "File10=C:\Windows\System32\UIEOrchestrator.exe"
set "File11=C:\Windows\System32\UpdateAgent.dll"
set "File12=C:\Windows\System32\UpdateCompression.dll"
set "File13=C:\Windows\SysWOW64\UpdateCompression.dll"
set "File14=C:\Windows\System32\updatecsp.dll"
set "File15=C:\Windows\System32\updatepolicy.dll"
set "File16=C:\Windows\System32\en-US\UpdatePolicy.dll.mui"
set "File17=C:\Windows\System32\UpdateReboot.dll"
set "File18=C:\Windows\System32\UpgradeResultsUI.exe"
set "File19=C:\Windows\System32\en-US\UpgradeResultsUI.exe.mui"
set "File20=C:\Windows\System32\upfc.exe"
set "File21=C:\Windows\System32\UsoClient.exe"
set "File22=C:\Windows\System32\WaaSAssessment.dll"
set "File23=C:\Windows\System32\WaaSMedicPS.dll"
set "File24=C:\Windows\System32\WaaSMedicSvc.dll"
set "File25=C:\Windows\System32\wuauclt.exe"
set "File26=C:\Windows\System32\wusa.exe"
set "File27=C:\Windows\System32\en-US\wusa.exe.mui"
set "File28=C:\Windows\SysWOW64\wusa.exe"
set "AllCopied=1"

for /L %%i in (1,1,28) do (
    set "UpdateApp=!File%%i!"
    if exist "!UpdateApp!" (
        copy "!UpdateApp!" "%BackupDir%\" >nul 2>&1
        if errorlevel 1 (
            set "AllCopied=0"
        )
    )
)

if %AllCopied%==1 (
    echo [%DATE% %TIME%] Update Disabler Apps Backup #2: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else (
    echo [%DATE% %TIME%] Update Disabler Apps Backup #2: Failed to copy all files. >> "C:\Oneclick Logs\Oneclick Log.txt"
)
endlocal

:: Creating Update Apps Backup.
setlocal enabledelayedexpansion
set "BackupDir=C:\Oneclick Tools\Update Disabler\Apps Backup\SysWOW64"
set "File1=C:\Windows\SysWOW64\UpdateCompression.dll"
set "File2=C:\Windows\SysWOW64\wusa.exe"
set "AllCopied=1"

for /L %%i in (1,1,2) do (
    set "UpdateApp=!File%%i!"
    if exist "!UpdateApp!" (
        copy "!UpdateApp!" "%BackupDir%\" >nul 2>&1
        if errorlevel 1 (
             set "AllCopied=0"
        )
    )
)

if %AllCopied%==1 (
    echo [%DATE% %TIME%] Update Disabler Apps Backup #3: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else (
    echo [%DATE% %TIME%] Update Disabler Apps Backup #3: Failed to copy all files. >> "C:\Oneclick Logs\Oneclick Log.txt"
)
endlocal

:: Deleting Update Services.
echo [%DATE% %TIME%] Update Disabler: Deleting Update Services. >> "C:\Oneclick Logs\Oneclick Log.txt"
sc delete "wuauserv" >nul 2>&1
sc delete "WaaSMedicSvc" >nul 2>&1
sc delete "UsoSvc" >nul 2>&1 

:: Defer Updates.
echo [%DATE% %TIME%] Update Disabler: Deferring updates. >> "C:\Oneclick Logs\Oneclick Log.txt"
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpdatePeriod" /t REG_DWORD /d "1" /f >nul 2>&1
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpgrade" /t REG_DWORD /d "1" /f >nul 2>&1
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DeferUpgradePeriod" /t REG_DWORD /d "1" /f >nul 2>&1
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /v "DisableWindowsUpdateAccess" /t REG_DWORD /d "1" /f >nul 2>&1

:: Permanently Pausing Updates.
echo [%DATE% %TIME%] Update Disabler: Pausing Updates. >> "C:\Oneclick Logs\Oneclick Log.txt"
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v PausedFeatureStatus /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy\Settings" /v PausedQualityStatus /t REG_DWORD /d 0 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v FlightSettingsMaxPauseDays /t REG_DWORD /d 3650 /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseFeatureUpdatesEndTime /t REG_SZ /d "3000-11-06T14:03:37Z" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseFeatureUpdatesStartTime /t REG_SZ /d "2023-11-06T14:03:37Z" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseQualityUpdatesEndTime /t REG_SZ /d "3000-11-06T14:03:37Z" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseQualityUpdatesStartTime /t REG_SZ /d "2023-11-06T14:03:37Z" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseUpdatesExpiryTime /t REG_SZ /d "3000-11-06T14:03:37Z" /f >nul 2>&1
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v PauseUpdatesStartTime /t REG_SZ /d "2023-11-06T14:03:37Z" /f >nul 2>&1

:: Deleting Windows Update Exe's.
echo [%DATE% %TIME%] Update Disabler: Deleting update exe's. >> "C:\Oneclick Logs\Oneclick Log.txt"
del "C:\Windows\System32\DoSvc.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\DoSvc.dll.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\MoNotificationUxStub.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\MusUpdateHandlers.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\MusUpdateHandlers.dll.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\MusUpdateHandlers1.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\MusUpdateHandlers1.dll.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\Sihclient.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\sihclient.exe.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\UIEOrchestrator.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\UpdateAgent.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\UpdateCompression.dll" /s /f /q >nul 2>&1
del "C:\Windows\SysWOW64\UpdateCompression.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\updatecsp.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\updatepolicy.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\UpdatePolicy.dll.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\UpdateReboot.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\UpgradeResultsUI.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\UpgradeResultsUI.exe.mui" /s /f /q >nul 2>&1
del "C:\Windows\System32\upfc.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\UsoClient.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\WaaSAssessment.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\WaaSMedicPS.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\WaaSMedicSvc.dll" /s /f /q >nul 2>&1
del "C:\Windows\System32\wuauclt.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\wusa.exe" /s /f /q >nul 2>&1
del "C:\Windows\System32\en-US\wusa.exe.mui" /s /f /q >nul 2>&1
del "C:\Windows\SysWOW64\wusa.exe" /s /f /q >nul 2>&1
rd /s /q "C:\Windows\UUS" >nul 2>&1

:: End Log.
echo [%DATE% %TIME%] Update Disabler V1.1: Successfully Ended. >> "C:\Oneclick Logs\Oneclick Log.txt"
exit
