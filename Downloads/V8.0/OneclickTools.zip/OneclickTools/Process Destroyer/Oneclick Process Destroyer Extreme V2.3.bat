:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

@echo off
title Process Destroyer Extreme V2.3
color B

:: Creating PD Extreme Services Reg Backup.
reg export "HKLM\System\CurrentControlSet\Services" "C:\Oneclick Tools\Process Destroyer\Revert\Services_Backup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] PD Extreme Services Reg Backup: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] PD Extreme Services Reg Backup: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating TrustedInstaller Reg Backup.
reg export "HKLM\System\CurrentControlSet\Services\TrustedInstaller" "C:\Oneclick Tools\Process Destroyer\Revert\Trusted_Installer_Backup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] PD Extreme TrustedInstaller Reg Backup: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] PD Extreme TrustedInstaller Reg Backup: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Creating Windows Installer Reg Backup.
reg export "HKLM\System\CurrentControlSet\Services\msiserver" "C:\Oneclick Tools\Process Destroyer\Revert\Windows_Installer_Backup.reg" /y >nul 2>&1
if errorlevel 1 (
    echo [%DATE% %TIME%] PD Extreme Windows Installer Reg Backup: Failed to create. >> "C:\Oneclick Logs\Oneclick Log.txt"
) else ( 
    echo [%DATE% %TIME%] PD Extreme Windows Installer Reg Backup: Created successfully. >> "C:\Oneclick Logs\Oneclick Log.txt"
)

:: Process Destroyer Extreme GUI.
cls
chcp 65001 >nul 2>&1
echo ╔═══════════════════════════════════════╗
echo ║ ✅ Running Process Destroyer Extreme. ║
echo ╚═══════════════════════════════════════╝
setlocal enabledelayedexpansion
timeout 2 > nul

:: Count Variables.
set "FoundCount=0"
set "NotFoundCount=0"
set "DeleteCount=0"

:: Windows Services.
set "svc1=AarSvc"
set "svc2=ADPSvc"
set "svc3=AJRouter"
set "svc4=ALG"
set "svc5=AppMgmt"
set "svc6=AppIDSvc"
set "svc7=AppInfo"
set "svc8=AppReadiness"
set "svc9=AppXSvc"
set "svc10=AssignedAccessManagerSvc"
set "svc11=autotimesvc"
set "svc12=AxInstSV"
set "svc13=BcastDVRUserService"
set "svc14=BDESVC"
set "svc15=BFE"
set "svc16=BITS"
set "svc17=BluetoothUserService"
set "svc18=BTAGService"
set "svc19=BthAvctpSvc"
set "svc20=bthserv"
set "svc21=CaptureService"
set "svc22=cbdhsvc"
set "svc23=CDPUserSvc"
set "svc24=CDPSvc"
set "svc25=CertPropSvc"
set "svc26=ClipSVC"
set "svc27=CloudBackupRestoreSvc"
set "svc28=cloudidsvc"
set "svc29=COMSysApp"
set "svc30=ConsentUxUserSvc"
set "svc31=CredentialEnrollmentManagerUserSvc"
set "svc32=CscService"
set "svc33=dcsvc"
set "svc34=defragsvc"
set "svc35=DeviceAssociationBrokerSvc"
set "svc36=DeviceAssociationService"
set "svc37=DevicePickerUserSvc"
set "svc38=DevicesFlowUserSvc"
set "svc39=DevQueryBroker"
set "svc40=diagnosticshub.standardcollector.service"
set "svc41=DiagTrack"
set "svc42=diagsvc"
set "svc43=DisplayEnhancementService"
set "svc44=DmEnrollmentSvc"
set "svc45=dmwappushservice"
set "svc46=Dnscache"
set "svc47=DoSvc"
set "svc48=dot3svc"
set "svc49=DPS"
set "svc50=DsmSvc"
set "svc51=DsSvc"
set "svc52=DusmSvc"
set "svc53=Eaphost"
set "svc54=EFS"
set "svc55=embeddedmode"
set "svc56=EntAppSvc"
set "svc57=EventLog"
set "svc58=EventSystem"
set "svc59=fdPHost"
set "svc60=FDResPub"
set "svc61=fhsvc"
set "svc62=FontCache"
set "svc63=FrameServer"
set "svc64=FrameServerMonitor"
set "svc65=GameInputSvc"
set "svc66=GraphicsPerfSvc"
set "svc67=gpsvc"
set "svc68=hidserv"
set "svc69=hpatchmon"
set "svc70=HvHost"
set "svc71=icssvc"
set "svc72=IKEEXT"
set "svc73=InstallService"
set "svc74=InventorySvc"
set "svc75=iphlpsvc"
set "svc76=IpxlatCfgSvc"
set "svc77=Keyiso"
set "svc78=KtmRm"
set "svc79=LanmanServer"
set "svc80=LanmanWorkstation"
set "svc81=lfsvc"
set "svc82=LocalKdc"
set "svc83=LicenseManager"
set "svc84=lltdsvc"
set "svc85=lmhosts"
set "svc86=LxpSvc"
set "svc87=MapsBroker"
set "svc88=McpManagementService"
set "svc89=McmSvc"
set "svc90=MessagingService"
set "svc91=midisrv"
set "svc92=MDCoreSvc"
set "svc93=mpssvc"
set "svc94=MSDTC"
set "svc95=MSiSCSI"
set "svc96=msiserver"
set "svc97=NaturalAuthentication"
set "svc98=NcaSvc"
set "svc99=NcbService"
set "svc100=NcdAutoSetup"
set "svc101=Netlogon"
set "svc102=Netman"
set "svc103=NetSetupSvc"
set "svc104=NetTcpPortSharing"
set "svc105=NgcCtnrSvc"
set "svc106=NgcSvc"
set "svc107=NlaSvc"
set "svc108=NPSMSvc"
set "svc109=OneSyncSvc"
set "svc110=p2pimsvc"
set "svc111=p2psvc"
set "svc112=P9RdrService"
set "svc113=PcaSvc"
set "svc114=PeerDistSvc"
set "svc115=PenService"
set "svc116=perceptionsimulation"
set "svc117=PerfHost"
set "svc118=PhoneSvc"
set "svc119=PimIndexMaintenanceSvc"
set "svc120=pla"
set "svc121=PlugPlay"
set "svc122=PNRPAutoReg"
set "svc123=PNRPsvc"
set "svc124=PrintDeviceConfigurationService"
set "svc125=PrintNotify"
set "svc126=PrintScanBrokerService"
set "svc127=PrintWorkflowUserSvc"
set "svc128=PushToInstall"
set "svc129=QWAVE"
set "svc130=RasAuto"
set "svc131=RasMan"
set "svc132=refsdedupsvc"
set "svc133=RemoteAccess"
set "svc134=RemoteRegistry"
set "svc135=RetailDemo"
set "svc136=RmSvc"
set "svc137=RpcLocator"
set "svc138=SamSs"
set "svc139=SCardSvr"
set "svc140=ScDeviceEnum"
set "svc141=SCPolicySvc"
set "svc142=SDRSVC"
set "svc143=Schedule"
set "svc144=seclogon"
set "svc145=SecurityHealthService"
set "svc146=SENS"
set "svc147=Sense"
set "svc148=SensorDataService"
set "svc149=SensorService"
set "svc150=SensrSvc"
set "svc151=SEMgrSvc"
set "svc152=SessionEnv"
set "svc153=SgrmBroker"
set "svc154=SharedAccess"
set "svc155=SharedRealitySvc"
set "svc156=ShellHWDetection"
set "svc157=shpamsvc"
set "svc158=SmsRouter"
set "svc159=smphost"
set "svc160=SNMPTrap"
set "svc161=Spooler"
set "svc162=SSDPSRV"
set "svc163=ssh-agent"
set "svc164=SstpSvc"
set "svc165=stisvc"
set "svc166=StorSvc"
set "svc167=svsvc"
set "svc168=SystemEventsBroker"
set "svc169=SysMain"
set "svc170=TapiSrv"
set "svc171=TermService"
set "svc172=Themes"
set "svc173=TieringEngineService"
set "svc174=TimeBrokerSvc"
set "svc175=TokenBroker"
set "svc176=TrkWks"
set "svc177=TroubleshootingSvc"
set "svc178=TrustedInstaller"
set "svc179=tzautoupdate"
set "svc180=UdkUserSvc"
set "svc181=UevAgentService"
set "svc182=uhssvc"
set "svc183=UmRdpService"
set "svc184=UnistoreSvc"
set "svc185=upnphost"
set "svc186=UserDataSvc"
set "svc187=VacSvc"
set "svc188=VaultSvc"
set "svc189=vds"
set "svc190=vmicguestinterface"
set "svc191=vmicheartbeat"
set "svc192=vmickvpexchange"
set "svc193=vmicrdv"
set "svc194=vmicshutdown"
set "svc195=vmictimesync"
set "svc196=vmicvmsession"
set "svc197=vmicvss"
set "svc198=W32Time"
set "svc199=WalletService"
set "svc200=WarpJITSvc"
set "svc201=wbengine"
set "svc202=WbioSrvc"
set "svc203=Wcmsvc"
set "svc204=wcncsvc"
set "svc205=WdNisSvc"
set "svc206=WdiServiceHost"
set "svc207=WdiSystemHost"
set "svc208=WebClient"
set "svc209=webthreatdefusersvc"
set "svc210=webthreatdefsvc"
set "svc211=Wecsvc"
set "svc212=WEPHOSTSVC"
set "svc213=wercplsupport"
set "svc214=WerSvc"
set "svc215=WFDSConMgrSvc"
set "svc216=whesvc"
set "svc217=WiaRpc"
set "svc218=WinDefend"
set "svc219=WinHttpAutoProxySvc"
set "svc220=WinRM"
set "svc221=wisvc"
set "svc222=WlanSvc"
set "svc223=wlidsvc"
set "svc224=wlpasvc"
set "svc225=WManSvc"
set "svc226=wmiApSrv"
set "svc227=WMPNetworkSvc"
set "svc228=workfolderssvc"
set "svc229=WpcMonSvc"
set "svc230=WPDBusEnum"
set "svc231=WpnUserService"
set "svc232=WpnService"
set "svc233=wuqisvc"
set "svc234=WSAIFabricSvc"
set "svc235=wscsvc"
set "svc236=WSearch"
set "svc237=WwanSvc"
set "svc238=XblAuthManager"
set "svc239=XblGameSave"
set "svc240=XboxGipSvc"
set "svc241=XboxNetApiSvc"

:: Service Delete Loop.
for /L %%i in (1,1,241) do (
    set "svc=!svc%%i!"
    reg query "HKLM\SYSTEM\CurrentControlSet\Services\!svc!" >nul 2>&1
    if !errorlevel! equ 0 (
        set /A "FoundCount+=1"
        echo [%DATE% %TIME%] !FoundCount!: Found !svc!. >> "C:\Oneclick Logs\Process Destroyer Extreme Log.txt"
        echo ✔  Deleting !svc!.
        reg delete "HKLM\SYSTEM\CurrentControlSet\Services\!svc!" /f >nul 2>&1
        reg query "HKLM\SYSTEM\CurrentControlSet\Services\!svc!" >nul 2>&1
        if !errorlevel! equ 0 (
            set /A "DeleteCount+=1"
            echo [%DATE% %TIME%] !DeleteCount!: Failed to delete !svc!. >> "C:\Oneclick Logs\Process Destroyer Extreme Log.txt"
        ) else (
            set /A "DeleteCount+=1"
            echo [%DATE% %TIME%] !DeleteCount!: Successfully deleted !svc!. >> "C:\Oneclick Logs\Process Destroyer Extreme Log.txt"
        )
    ) else (
        set /A "NotFoundCount+=1"
        echo [%DATE% %TIME%] !NotFoundCount!: !svc! not found. >> "C:\Oneclick Logs\Process Destroyer Extreme Log.txt"
    )
)

:: Set Software Protection to Manual.
reg add "HKLM\SYSTEM\CurrentControlSet\Services\sppsvc" /v "Start" /t REG_DWORD /d "3" /f >nul 2>&1

:: Removing Mpssvc and PolicyAgent. (SC Config, need to disable these services and mpssvc may not delete)
sc delete mpssvc >nul 2>&1
sc delete PolicyAgent >nul 2>&1

:: Rename Ctfmon, BackgroundTaskHost, and TextInputHost.
taskkill /f /im ctfmon.exe >nul 2>&1
REN "C:\Windows\System32\ctfmon.exe" "ctfmon.exee" >nul 2>&1
taskkill /f /im backgroundTaskHost.exe >nul 2>&1
REN "C:\Windows\System32\backgroundTaskHost.exe" "backgroundTaskHost.exee" >nul 2>&1
taskkill /f /im TextInputHost.exe >nul 2>&1
REN "C:\Windows\SystemApps\MicrosoftWindows.Client.CBS_cw5n1h2txyewy\TextInputHost.exe" "TextInputHost.exee" >nul 2>&1

:: Close.
echo ✔  Closing in 3 seconds...
timeout 3 > nul
exit
