:: Made by Quaked
:: TikTok: _Quaked_
:: Discord: https://discord.gg/8NqDSMzYun

:: Start Log.
echo [%DATE% %TIME%] Disable Optional Features: Successfully started. >> "C:\Oneclick Logs\Oneclick Log.txt"

:: Disable Optional Features. 
Powershell -NoProfile -Command ^
Disable-WindowsOptionalFeature -Online -FeatureName Client-ProjFS -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName DirectPlay -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName HypervisorPlatform -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationDevelopment -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationInit -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ASP -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ASPNET45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-BasicAuthentication -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-CGI -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-CommonHttpFeatures -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-CustomLogging -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-DefaultDocument -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-DirectoryBrowsing -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-FTPExtensibility -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-FTPServer -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-FTPSvc -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HealthAndDiagnostics -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HostableWebCore -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpCompressionDynamic -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpCompressionStatic -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpErrors -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpLogging -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpRedirect -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-HttpTracing -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-IIS6ManagementCompatibility -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-IPSecurity -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ISAPIExtensions -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ISAPIFilter -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-LegacyScripts -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-LoggingLibraries -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ManagementConsole -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ManagementScriptingTools -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ManagementService -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-Metabase -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-NetFxExtensibility -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-NetFxExtensibility45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-Performance -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-RequestFiltering -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-RequestMonitor -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-Security -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-ServerSideIncludes -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-StaticContent -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-URLAuthorization -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WebDAV -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WebServer -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerManagementTools -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WebSockets -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName IIS-WMICompatibility -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName LegacyComponents -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MediaPlayback -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Microsoft-Windows-Subsystem-Linux -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowershellV2 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MicrosoftWindowsPowershellV2Root -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-Container -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-DCOMProxy -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-HTTP -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-Multicast -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-Server -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSMQ-Triggers -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName MSRDC-Infrastructure -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName NetFx3 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-Foundation-Features -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-Foundation-InternetPrinting-Client -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-Foundation-LPDPrintService -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-Foundation-LPRPortMonitor -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-PrintToPDFServices-Features -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Printing-XPSServices-Features -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName SimpleTCP -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol-Client -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol-Deprecation -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName SMB1Protocol-Server -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName TelnetClient -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName TFTP -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName TIFFIFilter -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WAS-ConfigurationAPI -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WAS-NetFxEnvironment -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WAS-ProcessModel -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WAS-WindowsActivationService -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-HTTP-Activation -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-HTTP-Activation45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-MSMQ-Activation45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-NonHTTP-Activation -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-Pipe-Activation45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WCF-TCP-Activation45 -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName Windows-Identity-Foundation -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WindowsMediaPlayer -NoRestart -ErrorAction SilentlyContinue; ^
Disable-WindowsOptionalFeature -Online -FeatureName WorkFolders-Client -NoRestart -ErrorAction SilentlyContinue

:: End Log.
echo [%DATE% %TIME%] Disable Optional Features: Successfully Ended. >> "C:\Oneclick Logs\Oneclick Log.txt"
exit