:: Made by Quaked

:: Enable Nvidia Container.
sc config NVDisplay.ContainerLocalSystem start=auto >nul 2>&1
sc start NVDisplay.ContainerLocalSystem >nul 2>&1

exit