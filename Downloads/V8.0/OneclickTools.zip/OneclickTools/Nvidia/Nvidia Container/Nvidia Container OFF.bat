:: Made by Quaked

:: Disable Nvidia Container.
sc stop NVDisplay.ContainerLocalSystem >nul 2>&1
sc config NVDisplay.ContainerLocalSystem start=disabled >nul 2>&1

exit
