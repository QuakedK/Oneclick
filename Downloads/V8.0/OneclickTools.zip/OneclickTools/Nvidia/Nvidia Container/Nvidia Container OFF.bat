:: Made by Quaked

:: Disable Nvidia Container.
sc stop NVDisplay.ContainerLocalSystem
sc config NVDisplay.ContainerLocalSystem start=disabled >nul 2>&1

:: Disable Nvidia Telemetry Container.
sc stop NvTelemetryContainer
sc config NvTelemetryContainer start=disabled >nul 2>&1

exit
